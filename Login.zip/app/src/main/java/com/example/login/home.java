package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class home extends AppCompatActivity {
    ImageButton petrol,diesel,lpg,contact,wallet,logout;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        petrol=findViewById(R.id.petrol);
        diesel=findViewById(R.id.diesel);
        lpg=findViewById(R.id.lpg);
        contact=findViewById(R.id.contact);
        wallet=findViewById(R.id.wallet);
        logout=findViewById(R.id.logout);
        Intent i =new Intent(this,com.example.login.petrol.class);
        Intent intent=new Intent(this, Diesel.class);
        Intent intent1=new Intent(this, Lpg.class);
        Intent intent2=new Intent(this, Contactus.class);
        Intent intent4=new Intent(this,com.example.login.wallet.class);
        Intent intent5=new Intent(this, MainActivity.class);
        petrol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(i);
            }
        });
        diesel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(intent);
            }
        });
        lpg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
            }
        });
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent2);
            }
        });
        wallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent4);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent5);
            }
        });
    }
}