package com.example.login;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBase extends SQLiteOpenHelper {

    public static final String PASSWORDS = "Passwords";
    public static final String PASSWORD = "password";
    public static final String USERNAME = "username";
    public static final String EMAIL = "email";

    public DataBase(Context context) {
        super(context, "fuel.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "Create table " + PASSWORDS + " (" + PASSWORD + " varchar(10) not null," + USERNAME +
                " varchar(20) primary key not null," +
                EMAIL + " varchar(30) not null);";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public boolean addOne(Model model){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(USERNAME,model.getUsername());
        cv.put(PASSWORD,model.getPass());
        cv.put(EMAIL, model.getEmail());
        long insert = db.insert(PASSWORDS,null,cv);
        if(insert == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public List<Model> get_cred(){
        List<Model> list = new ArrayList<>();
        String query = "SELECT "+USERNAME+", "+PASSWORD+", "+EMAIL+" FROM "+PASSWORDS;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToFirst()){
            //Loop through cursor
            do{
                String password = cursor.getString(0);
                String username = cursor.getString(1);
                String email = cursor.getString(2);
                Model model = new Model(username,password,email);
                list.add(model);
            }while (cursor.moveToNext());
        }
        else{

        }
        return list;
    }

}

