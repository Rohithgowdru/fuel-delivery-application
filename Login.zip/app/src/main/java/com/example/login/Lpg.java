package com.example.login;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.login.R;

public class Lpg extends AppCompatActivity {
    public static final String lpg="lpg_id";
    public static int lpgs=72;
    EditText quantity;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lpg);
        quantity=findViewById(R.id.quantity);
    }
    public void lpg(View v)
    {
        Bundle b=new Bundle();
        b.putString("quantity",quantity.getText().toString());
        Intent i=new Intent(this, Cart.class);
        i.putExtra(lpg,lpgs);
        i.putExtras(b);
        startActivity(i);
    }
}