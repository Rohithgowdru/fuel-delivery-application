package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Diesel extends AppCompatActivity {
    public static final String diesel="diesel_id";
    public static int diesels=71;
    EditText quantity;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diesel);
        quantity=findViewById(R.id.quantity);
    }
    public void diesel(View v)
    {
        Bundle b=new Bundle();
        b.putString("quantity",quantity.getText().toString());
        Intent i=new Intent(this, Cart.class);
        i.putExtra(diesel,diesels);
        i.putExtras(b);
        startActivity(i);
    }
}