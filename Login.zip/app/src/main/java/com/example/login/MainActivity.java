package com.example.login;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    String fullname,fullpwd;
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button=findViewById(R.id.login);
        username=findViewById(R.id.uid);
        password=findViewById(R.id.pwd);
        Intent c = new Intent(this, home.class);
        button.setOnClickListener(v -> {
            try{
            DataBase db = new DataBase(MainActivity.this);
            List<Model> cred = db.get_cred();
            String name = username.getText().toString();
            String pwd = password.getText().toString();
            for (int i = 0; i < cred.size(); i++) {
                fullname = cred.get(i).username;
                fullpwd = cred.get(i).pass;
            }
                if (name.equals(fullname) && pwd.equals(fullpwd)) {
                    startActivity(c);
                }
                else {
                    Toast.makeText(this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e)
            {
                Toast.makeText(MainActivity.this, "wrong credentials", Toast.LENGTH_LONG).show();
            }
        });
        Intent i= new Intent(this, signup.class);
        TextView signup1=findViewById(R.id.signup1);
        String intext="New user?Signup here";
        SpannableString ss = new SpannableString(intext);
        ClickableSpan click1 = new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                Toast.makeText(MainActivity.this, "Signup here", Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
            @Override
            public void updateDrawState(TextPaint tp){
               super.updateDrawState(tp);
               tp.setColor(Color.BLACK);
               tp.setUnderlineText(true);
            }
        };
        ss.setSpan(click1,9,20, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        signup1.setText(ss);
        signup1.setMovementMethod(LinkMovementMethod.getInstance());
    }

}