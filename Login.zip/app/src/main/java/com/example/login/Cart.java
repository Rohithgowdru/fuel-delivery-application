package com.example.login;

import static com.example.login.Diesel.diesels;
import static com.example.login.Diesel.diesel;
import static com.example.login.Lpg.lpg;
import static com.example.login.Lpg.lpgs;
import static com.example.login.petrol.petrols;
import static com.example.login.petrol.petrol;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Cart extends AppCompatActivity {
    TextView price,delivery,tax,total;
    Button buynow;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        price=findViewById(R.id.price);
        delivery=findViewById(R.id.delivery);
        tax=findViewById(R.id.tax);
        total=findViewById(R.id.total);
        buynow=findViewById(R.id.buynow);
        Intent intent=new Intent(this, home.class);
        buynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
                Toast.makeText(Cart.this, "Successfully Purchased", Toast.LENGTH_LONG).show();
            }
        });
        int code=getIntent().getIntExtra(petrol,0);
        int code1=getIntent().getIntExtra(diesel,0);
        int code2=getIntent().getIntExtra(lpg,0);
        if(code==petrols)
        {
            adder();
        }
        else if(code1==diesels)
        {
            adder1();
        } else if (code2==lpgs) {
            adder2();

        }
    }
    public void adder()
    {
        try {
            Bundle b = getIntent().getExtras();
            int amt, sum;
            String qty = b.getString("quantity");
            int quant = Integer.parseInt(qty);
            amt = quant * 120;
            price.setText(Integer.toString(amt));
            delivery.setText("40");
            tax.setText("18");
            sum = amt + 40 + 18;
            total.setText(Integer.toString(sum));
        }
        catch (Exception e)
        {
            Toast.makeText(this, "error", Toast.LENGTH_LONG).show();
        }
    }
    public void adder1()
    {
        try{
            Bundle b=getIntent().getExtras();
            int amt,sum;
            String qty=b.getString("quantity");
            int quant = Integer.parseInt(qty);
            amt = quant * 100;
            price.setText(Integer.toString(amt));
            delivery.setText("40");
            tax.setText("18");
            sum = amt + 40 + 18;
            total.setText(Integer.toString(sum));

        }
        catch (Exception e)
        {
            Toast.makeText(this, "thappu", Toast.LENGTH_SHORT).show();
        }
    }
    public void adder2()
    {
        try{
            Bundle b=getIntent().getExtras();
            int amt,sum;
            String qty=b.getString("quantity");
            int quant = Integer.parseInt(qty);
            amt = quant *1250;
            price.setText(Integer.toString(amt));
            delivery.setText("50");
            tax.setText("18");
            sum = amt + 50 + 18;
            total.setText(Integer.toString(sum));

        }
        catch (Exception e)
        {
            Toast.makeText(this, "wrong", Toast.LENGTH_LONG).show();
        }
    }
}