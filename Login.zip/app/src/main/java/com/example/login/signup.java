package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class signup extends AppCompatActivity {
    EditText username,password,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup3);
        Button button= findViewById(R.id.signup);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        Intent i=new Intent(this,home.class);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Model model;
                try{
                    model=new Model(username.getText().toString(),password.getText().toString(),email.getText().toString());
                    Toast.makeText(signup.this, model.toString(), Toast.LENGTH_LONG).show();
                }catch (Exception e){
                    Toast.makeText(signup.this, "Error while creating database", Toast.LENGTH_SHORT).show();
                    model =new Model("error","error","error");
                }
                DataBase helper=new DataBase(signup.this);
                boolean success=helper.addOne(model);
                Toast.makeText(signup.this, "Success", Toast.LENGTH_SHORT).show();
                startActivity(i);

            }
        });
    }

    public static class Databasehelper {
    }
}